/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jogo;

/**
 *
 * @author1 Gabriel Henrique Teles Santos
 * @author2 Gabriel Dordal Tinelli
 * @since 27/06/18
 * @version 1.0
 */
public class DadVendas {
    private Integer codigo;
    private String nome;
    private String email;
    private Integer cep;
    private Integer mes;
    private Integer valorPago;
    private Integer valorTotalPago;
    private int quantJuros;
    private Integer valorJuros;
}
