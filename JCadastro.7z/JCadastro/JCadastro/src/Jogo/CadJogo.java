/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jogo;

/**
 *
 * @author1 Gabriel Henrique Teles Santos
 * @author2 Gabriel Dordal Tinelli
 * @since 27/06/18
 * @version 1.0
 */
public class CadJogo {
    private Integer codigo;
    private String nome;
    private String genero;
    private String plataforma;
    private int versao;
    private Integer valorTotal;
    private Integer parcelas;
}
